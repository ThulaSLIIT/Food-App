package com.example.cakeslk.Orders;

public class CalculateAmount {
    public double calAmount(int quanity, double unitprice){
        double amount = quanity * unitprice;
        return amount;
    }
}
