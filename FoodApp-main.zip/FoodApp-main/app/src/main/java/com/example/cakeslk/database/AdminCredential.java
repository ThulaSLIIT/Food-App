package com.example.cakeslk.database;

public class AdminCredential {
    public static final String AdminEmail = "admin@cakes.lk";
    public static final String AdminPassword= "Admin@23";
}
