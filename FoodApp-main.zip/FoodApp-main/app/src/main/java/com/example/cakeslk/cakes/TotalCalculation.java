package com.example.cakeslk.cakes;

public class TotalCalculation {
    public double totalCalculate(double price, int qty){
        double total = price*qty;
        return total;
    }
}
