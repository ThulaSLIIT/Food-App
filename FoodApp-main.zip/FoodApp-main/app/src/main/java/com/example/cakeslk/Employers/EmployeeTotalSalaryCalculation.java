package com.example.cakeslk.Employers;

public class EmployeeTotalSalaryCalculation  {
    public double totalSalCalculate (double sal, double bon){

        double total_sal = sal + bon;
        return total_sal;
    }
}